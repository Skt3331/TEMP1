package com.example.displayop; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonNext = findViewById(R.id.buttonNext);
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTextItem1 = findViewById(R.id.editTextItem1);
                EditText editTextItem2 = findViewById(R.id.editTextItem2);

                // Get the values from EditTexts
                double item1 = Double.parseDouble(editTextItem1.getText().toString());
                double item2 = Double.parseDouble(editTextItem2.getText().toString());

                // Create an Intent to start the second activity
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);

                // Pass the values to the second activity
                intent.putExtra("item1", item1);
                intent.putExtra("item2", item2);

                // Start the second activity
                startActivity(intent);
            }
        });
    }
}