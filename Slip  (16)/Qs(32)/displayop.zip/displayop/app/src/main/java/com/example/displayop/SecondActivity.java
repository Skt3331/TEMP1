package com.example.displayop;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTextItem3 = findViewById(R.id.editTextItem3);
                EditText editTextItem4 = findViewById(R.id.editTextItem4);

                // Get the values from EditTexts
                double item3 = Double.parseDouble(editTextItem3.getText().toString());
                double item4 = Double.parseDouble(editTextItem4.getText().toString());

                // Get the values from the first activity
                Intent intent = getIntent();
                double item1 = intent.getDoubleExtra("item1", 0);
                double item2 = intent.getDoubleExtra("item2", 0);

                // Create an Intent to start the third activity
                Intent resultIntent = new Intent(SecondActivity.this, ResultActivity.class);

                // Pass all values to the third activity
                resultIntent.putExtra("item1", item1);
                resultIntent.putExtra("item2", item2);
                resultIntent.putExtra("item3", item3);
                resultIntent.putExtra("item4", item4);

                // Start the third activity
                startActivity(resultIntent);
            }
        });
    }
}