package com.example.displayop; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Get the values from the Intent
        Intent intent = getIntent();
        double item1 = intent.getDoubleExtra("item1", 0);
        double item2 = intent.getDoubleExtra("item2", 0);
        double item3 = intent.getDoubleExtra("item3", 0);
        double item4 = intent.getDoubleExtra("item4", 0);

        // Perform calculations
        double result = item1 + item2 + item3 + item4; // Example calculation

        // Display the result
        TextView textViewResult = findViewById(R.id.textViewResult);
        textViewResult.setText("Result: " + result);
    }
}