package com.example.poweraverage; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Get the results from the Intent
        Intent intent = getIntent();
        double power = intent.getDoubleExtra("power", 0);
        double average = intent.getDoubleExtra("average", 0);

        // Display the results in the TextViews
        TextView textViewPower = findViewById(R.id.textViewPower);
        TextView textViewAverage = findViewById(R.id.textViewAverage);
        textViewPower.setText("Power: " + power);
        textViewAverage.setText("Average: " + average);
    }
}