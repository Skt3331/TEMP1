package com.example.poweraverage; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTextNumber1 = findViewById(R.id.editTextNumber1);
                EditText editTextNumber2 = findViewById(R.id.editTextNumber2);

                // Get the numbers from the EditTexts
                double num1 = Double.parseDouble(editTextNumber1.getText().toString());
                double num2 = Double.parseDouble(editTextNumber2.getText().toString());

                // Calculate power and average
                double power = Math.pow(num1, num2);
                double average = (num1 + num2) / 2;

                // Create an Intent to start the second activity
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);

                // Pass the results to the second activity
                intent.putExtra("power", power);
                intent.putExtra("average", average);

                // Start the second activity
                startActivity(intent);
            }
        });
    }
}