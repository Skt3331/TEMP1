package com.example.studentinfo;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText editTextRollNo, editTextName, editTextClass, editTextContact;
    Button buttonInsert, buttonDisplay;
    TextView textViewResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        editTextRollNo = findViewById(R.id.editTextRollNo);
        editTextName = findViewById(R.id.editTextName);
        editTextClass = findViewById(R.id.editTextClass);
        editTextContact = findViewById(R.id.editTextContact);
        buttonInsert = findViewById(R.id.buttonInsert);
        buttonDisplay = findViewById(R.id.buttonDisplay);
        textViewResults = findViewById(R.id.textViewResults);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertStudent();
            }
        });

        buttonDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayStudents();
            }
        });
    }

    private void insertStudent() {
        try {
            int rollNo = Integer.parseInt(editTextRollNo.getText().toString());
            String name = editTextName.getText().toString();
            String className = editTextClass.getText().toString();
            String contact = editTextContact.getText().toString();

            if (dbHelper.insertStudent(rollNo, name, className, contact)) {
                Toast.makeText(this, "Student inserted", Toast.LENGTH_SHORT).show();
                clearFields();
            } else {
                Toast.makeText(this, "Error inserting student", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayStudents() {
        Cursor cursor = dbHelper.getAllStudents();
        if (cursor.getCount() == 0) {
            textViewResults.setText("No students found");
            return;
        }

        StringBuilder buffer = new StringBuilder();
        while (cursor.moveToNext()) {
            buffer.append("Roll No: ").append(cursor.getInt(0)).append("\n");
            buffer.append("Name: ").append(cursor.getString(1)).append("\n");
            buffer.append("Class: ").append(cursor.getString(2)).append("\n");
            buffer.append("Contact: ").append(cursor.getString(3)).append("\n\n");
        }
        textViewResults.setText(buffer.toString());
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void clearFields() {
        editTextRollNo.setText("");
        editTextName.setText("");
        editTextClass.setText("");
        editTextContact.setText("");
    }
}