package com.example.registrationform;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RegisteredActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvAge, tvMobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvAge = findViewById(R.id.tvAge);
        tvMobile = findViewById(R.id.tvMobile);

        // Retrieve data from Intent
        String name = getIntent().getStringExtra("name");
        String email = getIntent().getStringExtra("email");
        String age = getIntent().getStringExtra("age");
        String mobile = getIntent().getStringExtra("mobile");

        // Set data to TextViews
        tvName.setText("Name: " + name);
        tvEmail.setText("Email: " + email);
        tvAge.setText("Age: " + age);
        tvMobile.setText("Mobile: " + mobile);
    }
}
