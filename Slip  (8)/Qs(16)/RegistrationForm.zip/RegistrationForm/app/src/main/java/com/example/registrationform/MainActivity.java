package com.example.registrationform;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword, etAge, etMobile;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etAge = findViewById(R.id.etAge);
        etMobile = findViewById(R.id.etMobile);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInput()) {
                    // If all fields are valid, proceed to the next activity
                    Intent intent = new Intent(MainActivity.this, RegisteredActivity.class);
                    intent.putExtra("name", etName.getText().toString().trim());
                    intent.putExtra("email", etEmail.getText().toString().trim());
                    intent.putExtra("age", etAge.getText().toString().trim());
                    intent.putExtra("mobile", etMobile.getText().toString().trim());
                    startActivity(intent);
                }
            }
        });
    }

    private boolean validateInput() {
        if (TextUtils.isEmpty(etName.getText().toString().trim())) {
            etName.setError("Name is required");
            return false;
        }

        String email = etEmail.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email");
            return false;
        }

        String password = etPassword.getText().toString();
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            return false;
        } else if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            return false;
        }

        String ageStr = etAge.getText().toString();
        if (TextUtils.isEmpty(ageStr)) {
            etAge.setError("Age is required");
            return false;
        }
        int age = Integer.parseInt(ageStr);
        if (age < 18) {
            etAge.setError("Age must be 18 or above");
            return false;
        }

        String mobile = etMobile.getText().toString().trim();
        if (TextUtils.isEmpty(mobile)) {
            etMobile.setError("Mobile number is required");
            return false;
        } else if (mobile.length() != 10) {
            etMobile.setError("Enter a valid 10-digit mobile number");
            return false;
        }

        return true;
    }
}
