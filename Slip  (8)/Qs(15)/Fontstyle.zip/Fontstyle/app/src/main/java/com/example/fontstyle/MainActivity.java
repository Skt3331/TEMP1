package com.example.fontstyle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private SeekBar seekBarSize;
    private Spinner spinnerColor, spinnerFontFamily;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        seekBarSize = findViewById(R.id.seekBarSize);
        spinnerColor = findViewById(R.id.spinnerColor);
        spinnerFontFamily = findViewById(R.id.spinnerFontFamily);

        setupSeekBar();
        setupColorSpinner();
        setupFontFamilySpinner();
    }

    private void setupSeekBar() {
        seekBarSize.setProgress(20);  // Default font size
        seekBarSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    private void setupColorSpinner() {
        String[] colors = {"Black", "Red", "Blue", "Green"};
        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, colors);
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColor.setAdapter(colorAdapter);

        spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                switch (position) {
                    case 0: textView.setTextColor(Color.BLACK); break;
                    case 1: textView.setTextColor(Color.RED); break;
                    case 2: textView.setTextColor(Color.BLUE); break;
                    case 3: textView.setTextColor(Color.GREEN); break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void setupFontFamilySpinner() {
        String[] fonts = {"Sans", "Serif", "Monospace"};
        ArrayAdapter<String> fontAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, fonts);
        fontAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFontFamily.setAdapter(fontAdapter);

        spinnerFontFamily.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                switch (position) {
                    case 0: textView.setTypeface(Typeface.SANS_SERIF); break;
                    case 1: textView.setTypeface(Typeface.SERIF); break;
                    case 2: textView.setTypeface(Typeface.MONOSPACE); break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
    }
}
