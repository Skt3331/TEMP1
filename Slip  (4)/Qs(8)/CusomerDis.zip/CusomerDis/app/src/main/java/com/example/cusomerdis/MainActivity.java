package com.example.cusomerdis;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextId, editTextName, editTextAddress, editTextPhone;
    TextView textViewCustomerDetails;
    CustomerDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set your layout file

        // Initialize UI elements
        editTextId = findViewById(R.id.edittext_id);
        editTextName = findViewById(R.id.edittext_name);
        editTextAddress = findViewById(R.id.edittext_address);
        editTextPhone = findViewById(R.id.edittext_phone);
        textViewCustomerDetails = findViewById(R.id.customer_details_textview);
        Button saveButton = findViewById(R.id.button_save);
        Button showButton = findViewById(R.id.button_show);

        // Initialize database helper
        dbHelper = new CustomerDatabaseHelper(this);

        // Set click listeners for buttons
        saveButton.setOnClickListener(v -> saveCustomer());
        showButton.setOnClickListener(v -> showCustomerDetails());
    }

    // Save customer data to database
    private void saveCustomer() {
        try {
            int id = Integer.parseInt(editTextId.getText().toString());
            String name = editTextName.getText().toString();
            String address = editTextAddress.getText().toString();
            String pho_no = editTextPhone.getText().toString();

            // Insert data into database
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("id", id);
            values.put("name", name);
            values.put("address", address);
            values.put("ph_no", pho_no);
            db.insert("Customer", null, values);
            db.close();

            clearInputFields();
            Toast.makeText(this, "Customer saved!", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Customer ID", Toast.LENGTH_SHORT).show();
        }
    }

    // Display customer details
    private void showCustomerDetails() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"id", "name", "address", "ph_no"};
        try (Cursor cursor = db.query("Customer", columns, null, null, null, null, null)) {
            StringBuilder details = new StringBuilder();
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                String pho_no = cursor.getString(cursor.getColumnIndexOrThrow("ph_no"));

                details.append("ID: ").append(id).append("\n");
                details.append("Name: ").append(name).append("\n");
                details.append("Address: ").append(address).append("\n");
                details.append("Phone No: ").append(pho_no).append("\n\n");
            }
            textViewCustomerDetails.setText(details.toString());
        } finally {
            db.close();
        }
    }

    // Clear input fields
    private void clearInputFields() {
        editTextId.setText("");
        editTextName.setText("");
        editTextAddress.setText("");
        editTextPhone.setText("");
    }
}

// Database helper class
