package com.example.studentclass;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText nameEditText, percentageEditText;
    Button addButton, displayButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        nameEditText = findViewById(R.id.nameEditText);
        percentageEditText = findViewById(R.id.percentageEditText);
        addButton = findViewById(R.id.addButton);
        displayButton = findViewById(R.id.displayButton);
        resultTextView = findViewById(R.id.resultTextView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudent();
            }
        });

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayFirstClassStudents();
            }
        });
    }

    private void addStudent() {
        String name = nameEditText.getText().toString();
        double percentage = Double.parseDouble(percentageEditText.getText().toString());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("percentage", percentage);

        long newRowId = db.insert("Student", null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Student added successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Error adding student", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    private void displayFirstClassStudents() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"roll_no", "name", "percentage"};
        String selection = "percentage >= 60"; // Assuming first class is 60% or above

        Cursor cursor = db.query("Student", columns, selection, null, null, null, null);
        StringBuilder result = new StringBuilder();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int rollNo = cursor.getInt(cursor.getColumnIndexOrThrow("roll_no"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                double percentage = cursor.getDouble(cursor.getColumnIndexOrThrow("percentage"));
                result.append("Roll No: ").append(rollNo).append("\nName: ").append(name).append("\nPercentage: ").append(percentage).append("\n\n");
            } while (cursor.moveToNext());
            resultTextView.setText(result.toString());
        } else {
            resultTextView.setText("No first class students found");
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }

    private void clearFields() {
        nameEditText.setText("");
        percentageEditText.setText("");
    }
}