package com.example.imageswitcher;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

public class MainActivity extends AppCompatActivity {

    private ImageSwitcher imageSwitcher;
    private Button buttonNext;
    private int currentImageIndex = 0;
    private int[] imageIds = {R.drawable.image1, R.drawable.image2, R.drawable.image3}; // Add your image IDs here

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSwitcher = findViewById(R.id.imageSwitcher);
        buttonNext = findViewById(R.id.buttonNext);

        // Set the ViewFactory for the ImageSwitcher
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                return imageView;
            }
        });

        // Load the first image
        imageSwitcher.setImageResource(imageIds[currentImageIndex]);

        // Set up the Next button click listener
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentImageIndex = (currentImageIndex + 1) % imageIds.length;
                imageSwitcher.setImageResource(imageIds[currentImageIndex]);

                // Add some animation (optional)
                Animation in = AnimationUtils.loadAnimation(MainActivity.this, android.R.anim.slide_in_left);
                Animation out = AnimationUtils.loadAnimation(MainActivity.this, android.R.anim.slide_out_right);
                imageSwitcher.setInAnimation(in);
                imageSwitcher.setOutAnimation(out);
            }
        });
    }
}