package com.example.employeeshow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText  editTextEId, editTextName, editTextAddress, editTextPhone;
    TextView textViewEmployeeDetails;
    EmployeeDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); 

        // Initialize UI elements
        editTextEId = findViewById(R.id.edittext_e_id);
        editTextName = findViewById(R.id.edittext_name);
        editTextAddress = findViewById(R.id.edittext_address);
        editTextPhone = findViewById(R.id.edittext_phone);
        textViewEmployeeDetails = findViewById(R.id.employee_details_textview);
        Button saveButton = findViewById(R.id.button_save);
        Button showButton = findViewById(R.id.button_show);

        // Initialize database helper
        dbHelper = new EmployeeDatabaseHelper(this);

        // Set click listeners for buttons
        saveButton.setOnClickListener(v -> saveEmployee());
        showButton.setOnClickListener(v -> showEmployeeDetails());
    }

    // Save employee data to database
    private void saveEmployee() {
        try {
            int E_id = Integer.parseInt(editTextEId.getText().toString());
            String name = editTextName.getText().toString();
            String address = editTextAddress.getText().toString();
            String pho_no = editTextPhone.getText().toString();

            // Insert data into database
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("E_id", E_id);
            values.put("name", name);
            values.put("address", address);
            values.put("pho_no", pho_no);
            db.insert("Employee", null, values);
            db.close();

            clearInputFields();
            Toast.makeText(this, "Employee saved!", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Employee ID", Toast.LENGTH_SHORT).show();
        }
    }

    // Display employee details
    private void showEmployeeDetails() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"E_id", "name", "address", "pho_no"};
        try (Cursor cursor = db.query("Employee", columns, null, null, null, null, null)) {
            StringBuilder details = new StringBuilder();
            while (cursor.moveToNext()) {
                int E_id = cursor.getInt(cursor.getColumnIndexOrThrow("E_id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                String pho_no = cursor.getString(cursor.getColumnIndexOrThrow("pho_no"));

                details.append("E_id: ").append(E_id).append("\n");
                details.append("Name: ").append(name).append("\n");
                details.append("Address: ").append(address).append("\n");
                details.append("Phone No: ").append(pho_no).append("\n\n");
            }
            textViewEmployeeDetails.setText(details.toString());
        } finally {
            db.close();
        }
    }

    // Clear input fields
    private void clearInputFields() {
        editTextEId.setText("");
        editTextName.setText("");
        editTextAddress.setText("");
        editTextPhone.setText("");
    }
}