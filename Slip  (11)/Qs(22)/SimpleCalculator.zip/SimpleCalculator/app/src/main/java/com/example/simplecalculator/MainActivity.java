package com.example.simplecalculator;



import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView display;
    String currentInput = "";
    String operator = "";
    double firstOperand = 0.0;
    boolean operatorSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        // Set onClickListeners for all buttons
        setButtonClickListener(R.id.button0, "0");
        setButtonClickListener(R.id.button1, "1");
        setButtonClickListener(R.id.button2, "2");
        setButtonClickListener(R.id.button3, "3");
        setButtonClickListener(R.id.button4, "4");
        setButtonClickListener(R.id.button5, "5");
        setButtonClickListener(R.id.button6, "6");
        setButtonClickListener(R.id.button7, "7");
        setButtonClickListener(R.id.button8, "8");
        setButtonClickListener(R.id.button9, "9");

        setButtonClickListener(R.id.buttonAdd, "+");
        setButtonClickListener(R.id.buttonSubtract, "-");
        setButtonClickListener(R.id.buttonMultiply, "*");
        setButtonClickListener(R.id.buttonDivide, "/");

        setButtonClickListener(R.id.buttonDecimal, ".");
        setButtonClickListener(R.id.buttonEquals, "=");
        setButtonClickListener(R.id.buttonClear, "C");
    }

    private void setButtonClickListener(int buttonId, final String buttonValue) {
        Button button = findViewById(buttonId);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonClick(buttonValue);
            }
        });
    }

    private void onButtonClick(String buttonValue) {
        switch (buttonValue) {
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                currentInput += buttonValue;
                display.setText(currentInput);
                break;
            case "+":
            case "-":
            case "*":
            case "/":
                if (!operatorSelected) {
                    firstOperand = Double.parseDouble(currentInput);
                    operator = buttonValue;
                    operatorSelected = true;
                    currentInput = "";
                } else {
                    performCalculation();
                    operator = buttonValue;
                }
                break;
            case ".":
                if (!currentInput.contains(".")) {
                    currentInput += ".";
                    display.setText(currentInput);
                }
                break;
            case "=":
                performCalculation();
                operatorSelected = false;
                operator = "";
                break;
            case "C":
                currentInput = "";
                operator = "";
                firstOperand = 0.0;
                operatorSelected = false;
                display.setText("");
                break;
        }
    }

    private void performCalculation() {
        if (!currentInput.isEmpty() && !operator.isEmpty()) {
            double secondOperand = Double.parseDouble(currentInput);
            double result = calculate(firstOperand, operator, secondOperand);
            display.setText(String.valueOf(result));
            firstOperand = result;
            currentInput = "";
        }
    }

    private double calculate(double firstOperand, String operator, double secondOperand) {
        switch (operator) {
            case "+":
                return firstOperand + secondOperand;
            case "-":
                return firstOperand - secondOperand;
            case "*":
                return firstOperand * secondOperand;
            case "/":
                if (secondOperand != 0) {
                    return firstOperand / secondOperand;
                } else {
                    display.setText("Error");
                    return 0.0;
                }
            default:
                return 0.0;
        }
    }
}