package com.example.studentinfo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;

public class MainActivity extends AppCompatActivity {

    EditText etName, etAddress, etPhno;
    Button btnInsert, btnShow;
    TextView tvOutput;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Assuming you have a layout with these elements

        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etPhno = findViewById(R.id.etPhno);
        btnInsert = findViewById(R.id.btnInsert);
        btnShow = findViewById(R.id.btnShow);
        tvOutput = findViewById(R.id.tvOutput);

        dbHelper = new DBHelper(this);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertStudent();
            }
        });

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStudents();
            }
        });
    }

    private void insertStudent() {
        String name = etName.getText().toString();
        String address = etAddress.getText().toString();
        String phno = etPhno.getText().toString();

        if (name.isEmpty() || address.isEmpty() || phno.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_NAME, name);
        values.put(DBHelper.COLUMN_ADDRESS, address);
        values.put(DBHelper.COLUMN_PHNO, phno);

        long newRowId = db.insert(DBHelper.TABLE_NAME, null, values);
        db.close();

        if (newRowId != -1) {
            Toast.makeText(this, "Student inserted successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Error inserting student", Toast.LENGTH_SHORT).show();
        }
    }

    private void showStudents() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DBHelper.TABLE_NAME, null, null, null, null, null, null);

        StringBuilder output = new StringBuilder();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_NAME));
            String address = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_ADDRESS));
            String phno = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_PHNO));

            output.append("ID: ").append(id).append("\n");
            output.append("Name: ").append(name).append("\n");
            output.append("Address: ").append(address).append("\n");
            output.append("Phone: ").append(phno).append("\n\n");
        }

        cursor.close();
        db.close();

        tvOutput.setText(output.toString());
    }

    private void clearFields() {
        etName.setText("");
        etAddress.setText("");
        etPhno.setText("");
    }
}