package com.example.tablediplay;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnGenerateTable;
    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        btnGenerateTable = findViewById(R.id.btnGenerateTable);
        tableLayout = findViewById(R.id.tableLayout);

        btnGenerateTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateTable();
            }
        });
    }

    private void generateTable() {
        String input = etNumber.getText().toString();

        // Validate input
        if (TextUtils.isEmpty(input)) {
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        int number = Integer.parseInt(input);
        tableLayout.removeAllViews(); // Clear previous table rows

        // Generate multiplication table
        for (int i = 1; i <= 10; i++) {
            // Create a new table row
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

            // Create TextViews for each column
            TextView multiplier = new TextView(this);
            multiplier.setText(String.valueOf(number));
            multiplier.setPadding(8, 8, 8, 8);

            TextView operator = new TextView(this);
            operator.setText(" x ");
            operator.setPadding(8, 8, 8, 8);

            TextView multiplicand = new TextView(this);
            multiplicand.setText(String.valueOf(i));
            multiplicand.setPadding(8, 8, 8, 8);

            TextView equals = new TextView(this);
            equals.setText(" = ");
            equals.setPadding(8, 8, 8, 8);

            TextView result = new TextView(this);
            result.setText(String.valueOf(number * i));
            result.setPadding(8, 8, 8, 8);

            // Add TextViews to the row
            row.addView(multiplier);
            row.addView(operator);
            row.addView(multiplicand);
            row.addView(equals);
            row.addView(result);

            // Add row to TableLayout
            tableLayout.addView(row);
        }
    }
}
