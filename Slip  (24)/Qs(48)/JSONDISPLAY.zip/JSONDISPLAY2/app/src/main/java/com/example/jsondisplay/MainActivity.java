package com.example.jsondisplay;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class MainActivity extends AppCompatActivity {

    TextView textViewEmployeeInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewEmployeeInfo = findViewById(R.id.textview_employee_info);

        // Sample JSON data (replace with your actual data)
        String jsonString = "[{\"id\":1,\"name\":\"Saurav Temgire\",\"department\":\"Technology\",\"city\":\"Pune\"}," +
                "{\"id\":2,\"name\":\"Vaibhav Zambare\",\"department\":\"Marketing\",\"city\":\"Mumbai\"}," +
                "{\"id\":3,\"name\":\"Priya Sharma\",\"department\":\"Finance\",\"city\":\"Bangalore\"}," +
                "{\"id\":4,\"name\":\"Rahul Verma\",\"department\":\"Human Resources\",\"city\":\"Delhi\"}]";

        displayEmployeeInfo(jsonString);
    }

    private void displayEmployeeInfo(String jsonString) {
        Gson gson = new Gson();
        JsonArray jsonArray = gson.fromJson(jsonString, JsonArray.class);

        StringBuilder employeeInfo = new StringBuilder();
        for (int i = 0; i < jsonArray.size(); i++) {
            JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
            int id = jsonObject.get("id").getAsInt();
            String name = jsonObject.get("name").getAsString();
            String department = jsonObject.get("department").getAsString();

            employeeInfo.append("ID: ").append(id).append("\n");
            employeeInfo.append("Name: ").append(name).append("\n");
            employeeInfo.append("Department: ").append(department).append("\n\n");
        }

        textViewEmployeeInfo.setText(employeeInfo.toString());
    }
}