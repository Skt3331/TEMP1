package com.example.tooglebtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    Switch mySwitch;
    TextView switchStatusTextView;
    ToggleButton myToggleButton;
    TextView toggleButtonStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mySwitch = findViewById(R.id.mySwitch);
        switchStatusTextView = findViewById(R.id.switchStatusTextView);
        myToggleButton = findViewById(R.id.myToggleButton);
        toggleButtonStatusTextView = findViewById(R.id.toggleButtonStatusTextView);

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    switchStatusTextView.setText("Switch is on");
                } else {
                    switchStatusTextView.setText("Switch is off");
                }
            }
        });

        myToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    toggleButtonStatusTextView.setText("Toggle button is on");
                } else {
                    toggleButtonStatusTextView.setText("Toggle button is off");
                }
            }
        });
    }
}