package com.example.studentdel;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText nameEditText, phoneEditText, sidToDeleteEditText;
    Button addButton, deleteButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        nameEditText = findViewById(R.id.nameEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        addButton = findViewById(R.id.addButton);
        resultTextView = findViewById(R.id.resultTextView);
        sidToDeleteEditText = findViewById(R.id.sidToDeleteEditText);
        deleteButton = findViewById(R.id.deleteButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudent();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteStudent();
            }
        });
    }

    private void addStudent() {
        String name = nameEditText.getText().toString();
        String phone = phoneEditText.getText().toString();

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Sname", name);
        values.put("phno", phone);

        long newRowId = db.insert("Student", null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Student added successfully", Toast.LENGTH_SHORT).show();
            displayStudentInfo(newRowId);
            clearFields();
        } else {
            Toast.makeText(this, "Error adding student", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    private void displayStudentInfo(long sid) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"Sid", "Sname", "phno"};
        String selection = "Sid = ?";
        String[] selectionArgs = {String.valueOf(sid)};

        Cursor cursor = db.query("Student", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("Sid"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("Sname"));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow("phno"));
            resultTextView.setText("ID: " + id + "\nName: " + name + "\nPhone: " + phone);
        } else {
            resultTextView.setText("Student not found");
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }

    private void deleteStudent() {
        String sidToDelete = sidToDeleteEditText.getText().toString();
        if (sidToDelete.isEmpty()) {
            Toast.makeText(this, "Please enter Sid to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = "Sid = ?";
        String[] selectionArgs = {sidToDelete};

        int deletedRows = db.delete("Student", selection, selectionArgs);
        if (deletedRows > 0) {
            Toast.makeText(this, "Student deleted successfully", Toast.LENGTH_SHORT).show();
            resultTextView.setText(""); // Clear the result TextView
        } else {
            Toast.makeText(this, "Error deleting student", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


    private void clearFields() {
        nameEditText.setText("");
        phoneEditText.setText("");
        sidToDeleteEditText.setText("");
    }
}