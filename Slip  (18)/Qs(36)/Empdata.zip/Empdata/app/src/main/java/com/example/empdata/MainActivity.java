package com.example.empdata;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText nameEditText, desgEditText, salaryEditText, searchNameEditText;
    Button addButton, searchButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        nameEditText = findViewById(R.id.nameEditText);
        desgEditText = findViewById(R.id.desgEditText);
        salaryEditText = findViewById(R.id.salaryEditText);
        addButton = findViewById(R.id.addButton);
        searchNameEditText = findViewById(R.id.searchNameEditText);
        searchButton = findViewById(R.id.searchButton);
        resultTextView = findViewById(R.id.resultTextView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addEmployee();
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchEmployee();
            }
        });
    }

    private void addEmployee() {
        String name = nameEditText.getText().toString();
        String desg = desgEditText.getText().toString();
        double salary = Double.parseDouble(salaryEditText.getText().toString());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("emp_name", name);
        values.put("emp_desg", desg);
        values.put("emp_salary", salary);

        long newRowId = db.insert("Employee", null, values);
        if (newRowId != -1) {
            Toast.makeText(this, "Employee added successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Error adding employee", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    private void searchEmployee() {
        String searchName = searchNameEditText.getText().toString();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"emp_id", "emp_name", "emp_desg", "emp_salary"};
        String selection = "emp_name = ?";
        String[] selectionArgs = {searchName};

        Cursor cursor = db.query("Employee", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("emp_id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("emp_name"));
            String desg = cursor.getString(cursor.getColumnIndexOrThrow("emp_desg"));
            double salary = cursor.getDouble(cursor.getColumnIndexOrThrow("emp_salary"));
            resultTextView.setText("ID: " + id + "\nName: " + name + "\nDesignation: " + desg + "\nSalary: " + salary);
        } else {
            resultTextView.setText("Employee not found");
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }

    private void clearFields() {
        nameEditText.setText("");
        desgEditText.setText("");
        salaryEditText.setText("");
    }
}