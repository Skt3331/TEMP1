package com.example.scroll; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get references to all the buttons
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);
        Button button10 = findViewById(R.id.button10);
        Button button11 = findViewById(R.id.button11);
        Button button12 = findViewById(R.id.button12);

        // Set click listeners for each button
        button1.setOnClickListener(v -> showToast("Button 1 was clicked!"));
        button2.setOnClickListener(v -> showToast("Button 2 was clicked!"));
        button3.setOnClickListener(v -> showToast("Button 3 was clicked!"));
        button4.setOnClickListener(v -> showToast("Button 4 was clicked!"));
        button5.setOnClickListener(v -> showToast("Button 5 was clicked!"));
        button6.setOnClickListener(v -> showToast("Button 6 was clicked!"));
        button7.setOnClickListener(v -> showToast("Button 7 was clicked!"));
        button8.setOnClickListener(v -> showToast("Button 8 was clicked!"));
        button9.setOnClickListener(v -> showToast("Button 9 was clicked!"));
        button10.setOnClickListener(v -> showToast("Button 10 was clicked!"));
        button11.setOnClickListener(v -> showToast("Button 11 was clicked!"));
        button12.setOnClickListener(v -> showToast("Button 12 was clicked!"));
    }

    // Helper function to show Toast messages
    private void showToast(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}