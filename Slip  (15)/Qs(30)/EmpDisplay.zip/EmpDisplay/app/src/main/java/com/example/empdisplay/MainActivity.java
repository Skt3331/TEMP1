package com.example.empdisplay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered information
                String firstName = ((EditText) findViewById(R.id.editTextFirstName)).getText().toString();
                String middleName = ((EditText) findViewById(R.id.editTextMiddleName)).getText().toString();
                String lastName = ((EditText) findViewById(R.id.editTextLastName)).getText().toString();
                String dob = ((EditText) findViewById(R.id.editTextDob)).getText().toString();
                String address = ((EditText) findViewById(R.id.editTextAddress)).getText().toString();
                String email = ((EditText) findViewById(R.id.editTextEmail)).getText().toString();

                // Create an Intent to start the second activity
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);

                // Pass the information to the second activity
                intent.putExtra("firstName", firstName);
                intent.putExtra("middleName", middleName);
                intent.putExtra("lastName", lastName);
                intent.putExtra("dob", dob);
                intent.putExtra("address", address);
                intent.putExtra("email", email);

                // Start the second activity
                startActivity(intent);
            }
        });
    }
}