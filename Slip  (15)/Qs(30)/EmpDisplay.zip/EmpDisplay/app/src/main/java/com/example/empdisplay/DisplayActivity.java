package com.example.empdisplay; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        // Get the information from the Intent
        Intent intent = getIntent();
        String firstName = intent.getStringExtra("firstName");
        String middleName = intent.getStringExtra("middleName");
        String lastName = intent.getStringExtra("lastName");
        String dob = intent.getStringExtra("dob");
        String address = intent.getStringExtra("address");
        String email = intent.getStringExtra("email");

        // Display the information in the TextViews
        ((TextView) findViewById(R.id.textViewFirstName)).setText("First Name: " + firstName);
        ((TextView) findViewById(R.id.textViewMiddleName)).setText("Middle Name: " + middleName);
        ((TextView) findViewById(R.id.textViewLastName)).setText("Last Name: " + lastName);
        ((TextView) findViewById(R.id.textViewDob)).setText("Date of Birth: " + dob);
        ((TextView) findViewById(R.id.textViewAddress)).setText("Address: " + address);
        ((TextView) findViewById(R.id.textViewEmail)).setText("Email ID: " + email);
    }
}