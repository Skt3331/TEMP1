package com.example.powerandaverage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextNum1, editTextNum2;
    Button buttonPower, buttonAverage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNum1 = findViewById(R.id.edittext_num1);
        editTextNum2 = findViewById(R.id.edittext_num2);
        buttonPower = findViewById(R.id.button_power);
        buttonAverage = findViewById(R.id.button_average);

        buttonPower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatePower();
            }
        });

        buttonAverage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAverage();
            }
        });
    }

    private void calculatePower() {
        try {
            double num1 = Double.parseDouble(editTextNum1.getText().toString());
            double num2 = Double.parseDouble(editTextNum2.getText().toString());
            double result = Math.pow(num1, num2);
            startResultActivity("Power: " + result);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateAverage() {
        try {
            double num1 = Double.parseDouble(editTextNum1.getText().toString());
            double num2 = Double.parseDouble(editTextNum2.getText().toString());
            double result = (num1 + num2) / 2;
            startResultActivity("Average: " + result);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
        }
    }

    private void startResultActivity(String result) {
        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("result", result);
        startActivity(intent);
    }
}