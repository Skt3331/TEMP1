package com.example.listviewoperations;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    Button btnAdd, btnDelete, btnSearch;
    EditText editText;
    ListView listView;

    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.buttonAdd);
        btnDelete = findViewById(R.id.buttonDelete);
        btnSearch = findViewById(R.id.buttonSearch);
        editText = findViewById(R.id.editText);
        listView = findViewById(R.id.listView);

        // Sample initial data
        String[] items = {"Apple", "Banana", "Orange", "Grapes"};
        arrayList = new ArrayList<>(Arrays.asList(items));

        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newItem = editText.getText().toString();
                if (!newItem.isEmpty()) {
                    arrayList.add(newItem);
                    arrayAdapter.notifyDataSetChanged();
                    editText.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Please enter an item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String itemToDelete = editText.getText().toString();
                if (!itemToDelete.isEmpty()) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Confirm Delete")
                            .setMessage("Are you sure you want to delete " + itemToDelete + "?")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    if (arrayList.remove(itemToDelete)) {
                                        arrayAdapter.notifyDataSetChanged();
                                        editText.setText("");
                                    } else {
                                        Toast.makeText(MainActivity.this, "Item not found", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                } else {
                    Toast.makeText(MainActivity.this, "Please enter an item to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemToSearch = editText.getText().toString();
                if (!itemToSearch.isEmpty()) {
                    if (arrayList.contains(itemToSearch)) {
                        Toast.makeText(MainActivity.this, "Item found!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Item not found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter an item to search", Toast.LENGTH_SHORT).show();
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String selectedItem = arrayList.get(position);
                editText.setText(selectedItem);
            }
        });
    }
}