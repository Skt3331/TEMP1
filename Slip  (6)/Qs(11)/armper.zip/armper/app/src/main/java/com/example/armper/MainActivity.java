package com.example.armper;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextNumber;
    Button buttonCheck;
    TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.edittext_number);
        buttonCheck = findViewById(R.id.button_check);
        textViewResult = findViewById(R.id.textview_result);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkNumber();
            }
        });
    }

    private void checkNumber() {
        try {
            int number = Integer.parseInt(editTextNumber.getText().toString());
            String result = "";

            if (isArmstrongNumber(number)) {
                result += number + " is an Armstrong number.\n";
            } else {
                result += number + " is not an Armstrong number.\n";
            }

            if (isPerfectNumber(number)) {
                result += number + " is a Perfect number.";
            } else {
                result += number + " is not a Perfect number.";
            }

            textViewResult.setText(result);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isArmstrongNumber(int number) {
        int originalNumber, remainder, result = 0, n = 0;
        originalNumber = number;

        for (; originalNumber != 0; originalNumber /= 10, ++n);

        originalNumber = number;

        for (; originalNumber != 0; originalNumber /= 10) {
            remainder = originalNumber % 10;
            result += Math.pow(remainder, n);
        }

        return result == number;
    }

    private boolean isPerfectNumber(int number) {
        if (number <= 1) {
            return false;
        }

        int sum = 1;
        for (int i = 2; i * i <= number; i++) {
            if (number % i == 0) {
                sum += i;
                if (i * i != number) {
                    sum += number / i;
                }
            }
        }

        return sum == number;
    }
}