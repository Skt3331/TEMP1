package com.example.greetperson;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        messageTextView = findViewById(R.id.textViewMessage);

        Intent intent = getIntent();
        String message = intent.getStringExtra("greet_message");
        messageTextView.setText(message);
    }
}