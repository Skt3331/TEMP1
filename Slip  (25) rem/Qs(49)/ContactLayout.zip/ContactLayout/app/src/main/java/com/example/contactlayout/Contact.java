package com.example.contactlayout;
public class Contact {
    private String name;
    private String phoneNumber;
    private String email;
    private int photoId;

    public Contact(String name, String phoneNumber, String email, int photoId) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.photoId = photoId;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public int getPhotoId() {
        return photoId;
    }

    // Setters (optional, if you need to modify contact details)
    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }
}