package com.example.contactlayout;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView contactListView = findViewById(R.id.contact_list);

        List<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact("Aarav Sharma", "+91-9876543210", "aarav.sharma@example.com", R.drawable.img));

        contacts.add(new Contact("Rohan Singh", "+91-7654321098", "rohan.singh@example.com", R.drawable.img_2));


        contacts.add(new Contact("Rahul Gupta", "+91-8123456789", "rahul.gupta@example.com", R.drawable.img_1));

        contacts.add(new Contact("Vikram Kumar", "+91-9876054321", "vikram.kumar@example.com", R.drawable.img));


        ContactAdapter adapter = new ContactAdapter(this, contacts);
        contactListView.setAdapter(adapter);
    }
}