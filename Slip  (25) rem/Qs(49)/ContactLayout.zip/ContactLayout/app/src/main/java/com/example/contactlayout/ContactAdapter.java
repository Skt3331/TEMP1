package com.example.contactlayout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class ContactAdapter extends ArrayAdapter<Contact> {

    public ContactAdapter(Context context, List<Contact> contacts) {
        super(context, 0, contacts);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Contact contact = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.contact_item, parent, false);
        }

        ImageView photoImageView = convertView.findViewById(R.id.contact_photo);
        TextView nameTextView = convertView.findViewById(R.id.contact_name);
        TextView numberTextView = convertView.findViewById(R.id.contact_number);
        TextView emailTextView = convertView.findViewById(R.id.contact_email);

        photoImageView.setImageResource(contact.getPhotoId());
        nameTextView.setText(contact.getName());
        numberTextView.setText(contact.getPhoneNumber());
        emailTextView.setText(contact.getEmail());

        return convertView;
    }
}