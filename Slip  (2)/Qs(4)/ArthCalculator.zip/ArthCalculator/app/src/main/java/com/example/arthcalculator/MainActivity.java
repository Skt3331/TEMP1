package com.example.arthcalculator;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView display;
    String input = "";
    String operator = "";
    double num1 = 0, num2 = 0, result = 0;
    double lastAnswer = 0; // To store the last answer

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        // Set onClickListeners for all buttons
        int[] buttonIds = {
                R.id.button0, R.id.button1, R.id.button2, R.id.button3,
                R.id.button4, R.id.button5, R.id.button6, R.id.button7,
                R.id.button8, R.id.button9, R.id.buttonAdd, R.id.buttonSubtract,
                R.id.buttonMultiply, R.id.buttonDivide, R.id.buttonDecimal,
                R.id.buttonPercent, R.id.buttonEquals, R.id.buttonDel,
                R.id.buttonAnswer
        };

        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();

        if (buttonText.equals("DEL")) {
            // Delete the last character
            if (!input.isEmpty()) {
                input = input.substring(0, input.length() - 1);
                display.setText(input);
            }
        } else if (buttonText.equals("ANSWER")) {
            // Recall the last answer
            input = String.valueOf(lastAnswer);
            display.setText(input);
        } else if (buttonText.equals("=")) {
            // Perform calculation
            if (!input.isEmpty() && !operator.isEmpty()) {
                num2 = Double.parseDouble(input);
                switch (operator) {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "x":
                        result = num1 * num2;
                        break;
                    case "/":
                        if (num2 != 0) {
                            result = num1 / num2;
                        } else {
                            display.setText("Error");
                            return;
                        }
                        break;
                }
                display.setText(String.valueOf(result));
                lastAnswer = result; // Store the answer
                input = String.valueOf(result); // Update input for further calculations
                operator = "";
            }
        } else if (buttonText.equals("+") || buttonText.equals("-") ||
                buttonText.equals("x") || buttonText.equals("/")) {
            // Store operator and first number
            if (!input.isEmpty()) {
                operator = buttonText;
                num1 = Double.parseDouble(input);
                input = "";
            }
        } else {
            // Append digit to input
            input += buttonText;
            display.setText(input);
        }
    }
}