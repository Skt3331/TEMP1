package com.example.armstrong;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editTextNumber;
    Button checkButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.editTextNumber);
        checkButton = findViewById(R.id.checkButton);
        resultTextView = findViewById(R.id.resultTextView);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkArmstrongNumber();
            }
        });
    }

    private void checkArmstrongNumber() {
        String input = editTextNumber.getText().toString();
        if (input.isEmpty()) {
            resultTextView.setText("Please enter a number");
            return;
        }

        int number = Integer.parseInt(input);
        int originalNumber = number;
        int result = 0;
        int digits = String.valueOf(number).length();

        while (originalNumber != 0) {
            int remainder = originalNumber % 10;
            result += Math.pow(remainder, digits);
            originalNumber /= 10;
        }

        if (result == number) {
            resultTextView.setText(number + " is an Armstrong number");
        } else {
            resultTextView.setText(number + " is not an Armstrong number");
        }
    }
}