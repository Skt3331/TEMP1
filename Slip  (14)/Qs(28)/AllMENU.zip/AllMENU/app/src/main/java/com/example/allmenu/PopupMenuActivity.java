package com.example.allmenu;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PopupMenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup_menu);

        Button btnShowPopupMenu = findViewById(R.id.btnShowPopupMenu);
        btnShowPopupMenu.setOnClickListener(this::showPopupMenu);
    }

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.popup_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(this::onPopupMenuItemClick);
        popup.show();
    }

    private boolean onPopupMenuItemClick(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.popup_option1) {
            Toast.makeText(this, "Popup Option 1 Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (itemId == R.id.popup_option2) {
            Toast.makeText(this, "Popup Option 2 Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else {
            return false;
        }
    }
}
