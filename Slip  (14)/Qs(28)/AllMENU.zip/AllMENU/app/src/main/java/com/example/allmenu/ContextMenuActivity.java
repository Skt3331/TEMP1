package com.example.allmenu;

import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ContextMenuActivity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_context_menu);

        textView = findViewById(R.id.textView);
        registerForContextMenu(textView);

        // Debug logs to verify ID generation
        Log.d("ContextMenuActivity", "context_option1 ID: " + R.id.context_option1);
        Log.d("ContextMenuActivity", "context_option2 ID: " + R.id.context_option2);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.context_option1) {
            Toast.makeText(this, "Context Option 1 Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (itemId == R.id.context_option2) {
            Toast.makeText(this, "Context Option 2 Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }
}
