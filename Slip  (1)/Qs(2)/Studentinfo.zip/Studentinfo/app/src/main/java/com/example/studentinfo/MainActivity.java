package com.example.studentinfo; // Replace with your package name

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DBHelper myDb;
    EditText editRollNo, editName, editAddress, editPercentage;
    Button buttonAdd;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DBHelper(this);
        editRollNo = findViewById(R.id.editTextRollNo);
        editName = findViewById(R.id.editTextName);
        editAddress = findViewById(R.id.editTextAddress);
        editPercentage = findViewById(R.id.editTextPercentage);
        buttonAdd = findViewById(R.id.buttonAdd);
        textView = findViewById(R.id.textView);

        addData();
        viewAll();
    }

    public void addData() {
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rollno = editRollNo.getText().toString();
                String name = editName.getText().toString();
                String address = editAddress.getText().toString();
                String percentage = editPercentage.getText().toString();

                if (rollno.isEmpty() || name.isEmpty() || address.isEmpty() || percentage.isEmpty()) {
                    showMessage("Error", "Please fill all fields");
                    return;
                }

                boolean isInserted = myDb.insertData(rollno, name, address, Double.parseDouble(percentage));
                if (isInserted) {
                    showMessage("Success", "Data inserted");
                    clearFields(); // Clear input fields after insertion
                    viewAll(); // Refresh the displayed data
                } else {
                    showMessage("Error", "Data not inserted");
                }
            }
        });
    }

    public void viewAll() {
        Cursor res = myDb.getAllData();
        if (res.getCount() == 0) {
            textView.setText("No data found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append("Roll No: " + res.getString(0) + "\n");
            buffer.append("Name: " + res.getString(1) + "\n");
            buffer.append("Address: " + res.getString(2) + "\n");
            buffer.append("Percentage: " + res.getString(3) + "\n\n");
        }

        textView.setText(buffer.toString());
    }

    public void showMessage(String title, String message) {
        Toast.makeText(this, title + ": " + message, Toast.LENGTH_LONG).show();
    }

    // Helper method to clear input fields
    private void clearFields() {
        editRollNo.setText("");
        editName.setText("");
        editAddress.setText("");
        editPercentage.setText("");
    }
}